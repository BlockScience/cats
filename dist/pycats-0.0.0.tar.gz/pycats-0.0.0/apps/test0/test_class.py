from pycats import CATS_HOME, CATSTORE
from apps.cat0 import catFactory
from pycats.function.process.cat import Processor


# if __name__ == "__main__":
cat: Processor = catFactory.init_processor(ipfs_daemon=True)
local_bom_write_path = f'{CATS_HOME}/catStore/bom.json',
cai_bom, input_cad_invoice = cat.content_address_input(
    input_data_uri=f'{CATS_HOME}/catStore/cats-public/input/df',  # I
    # input_data_uri='s3://cats-public/input/df',  # I
    invoice_uri=f'{CATSTORE}/cad/cai/invoices',  # O
    # invoice_uri='s3://cats-public/cad-store/cad/cai/invoices',  # O
    bom_write_path_uri='s3://cats-public/cad-store/cad/cai/bom/bom.json',  # O
    output_data_uri='s3://cats-public/cad-store/cad/cao/data',  # I/O
    transformer_uri=f'{CATSTORE}/cad/transformation/transform.py',  # I/O
    # transformer_uri='s3://cats-public/cad-store/cad/transformation/transform.py', # I/O
    cai_partitions=1
)

# content of test_class.py
class TestClass:
    def test_two(self):
        x = """
        {'action': 'added',
         'bom_cid': 'QmUjLoRdYtwvEPW63R4s5XHQeVeXXKGygjuTaGyiwoHLQD',
         'bom_uri': 's3://cats-public/cad-store/cad/cai/bom/bom.json',
         'cai_data_uri': 's3://cats-public/cad-store/cad/cao/data',
         'cai_invoice_uri': 's3://cats-public/cad-store/cad/cai/invoices',
         'cai_part_cids': ['QmSNBaSYYmvmAvWmVpXFSiDfr5u1RW3EZwSUYkibwbG6BZ'],
         'input_bom_cid': '',
         'log_write_path_uri': 's3://cats-public/cad-store/cad/cai/bom/bom_cat_log.json',
         'terraform_cid': 'QmWdBbaixRNFJUDLD7v7Z3bnyCPRHpxBb31EByx8nsD24W',
         'terraform_file': '/home/jjodesty/Projects/Research/cats/main.tf',
         'terraform_filename': 'main.tf',
         'terraform_node_path': '/tmp/main.tf',
         'transform_cid': 'QmRL4zysjoDURNWqCehR1mNCDcMVG1oDpKvguJSmnyhb1e',
         'transform_filename': 'transform.py',
         'transform_node_path': '/opt/spark/work-dir/job/transformation/transform.py',
         'transform_uri': 's3://cats-public/cad-store/cad/transformation/transform.py',
         'transformer_uri': 's3://cats-public/cad-store/cad/transformation/transform.py'}
        """
        assert x == cat.cai_bom
