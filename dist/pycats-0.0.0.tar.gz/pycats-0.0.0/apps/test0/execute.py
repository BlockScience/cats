from apps.cat0 import catFactory

# catFactory.build_cats()
# catFactory.terraform()
catFactory.execute()