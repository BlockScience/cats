from apps.cat1 import catFactory

catFactory.build_cats()
catFactory.terraform()
catFactory.execute()