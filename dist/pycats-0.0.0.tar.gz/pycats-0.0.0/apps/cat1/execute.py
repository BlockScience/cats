from apps.cat1 import catFactory

# catFactory.build_cats()
catFactory.terraform()
catFactory.execute()

# 15:35:43
# 15:37:28