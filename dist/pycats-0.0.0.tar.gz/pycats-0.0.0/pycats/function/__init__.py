WORK_DIR = '/opt/spark/work-dir'
INVOICE_DIR = f"{WORK_DIR}/job/invoice"

INPUT_DIR = f"{WORK_DIR}/job/input"
INPUT = f"{WORK_DIR}/job/input/df"
OUTPUT = f"{WORK_DIR}/job/output/df"

TRANSFORM_DIR = f"{WORK_DIR}/job/transformation"
IPFS_DIR = f'{WORK_DIR}/ipfs'