import os

CATS_HOME = os.getenv('CATS_HOME')
SPARK_HOME = os.getenv('SPARK_HOME')
DRIVER_IPFS_DIR = f'{CATS_HOME}/catStore'
CATSTORE = f'{CATS_HOME}/catStore/cats-public/cad-store'
AWS_ACCESS_KEY_ID = os.getenv('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = os.getenv('AWS_SECRET_ACCESS_KEY')
