import os
import subprocess

from pycats.function.process.utils2 import INPUT
from pycats.function.process.utils2.s3 import s3_client


def ipfs_connect(cad_part_invoice):
    addresses = cad_part_invoice['addresses']
    for address in addresses:
        output = subprocess.check_output(f"ipfs swarm connect {address}".split(' ')) \
            .decode('ascii').replace('\n', '').split(' ')
        if output[2] == 'success':
            cad_part_invoice['connection'] = address
        else:
            cad_part_invoice['connection'] = None
        return cad_part_invoice


def s3_ingest(cad_part_invoice):
    cid = cad_part_invoice['cid']
    filename = cad_part_invoice['filename']
    bucket = 'cats-public'
    key = 'cad-store/cad/cai/parts'
    uri = f's3a://{bucket}/{key}'
    subprocess.check_call(f"mkdir -p {INPUT}".split(' '))

    os.chdir(INPUT)
    output = subprocess.check_output(f"ipfs get {cid}".split(' ')).decode('ascii').replace('\n', '')
    if output == f'Saving file(s) to {cid}':
        subprocess.check_call(f"mv {cid} {filename}".split(' '))
        try:
            file = open(filename, "rb")
            s3_client.upload_fileobj(file, Bucket=bucket, Key=key)
            cad_part_invoice['upload_path'] = uri
            return cad_part_invoice
        except Exception as e:
            cad_part_invoice['upload_path'] = str(e)
            return cad_part_invoice

def cluster_fs_ingest(cad_part_invoice):
    return s3_ingest(ipfs_connect(cad_part_invoice))


def get_upload_path(cad_part_invoice):
    return str(cad_part_invoice['upload_path'])