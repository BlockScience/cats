

# def content_address_tranformation(transform_uri):
import json
import subprocess

from pycats.function.process.utils2 import TRANSFORM_DIR, IPFS_DIR, WORK_DIR
from pycats.function.process.utils2.s3 import s3_client


# def content_address_tranformation(transform_uri):
def content_address_transformer(transform_uri):
    # 's3a://cats-public/cad-store/cad/transformation/transform.py'
    transform_bucket = transform_uri.split('s3a://')[-1].split('/')[0]
    transform_key = transform_uri.split('s3a://')[-1].split(transform_bucket)[-1][1:]
    transform_filename = transform_key.split('/')[-1]
    NODE_FILE_PATH = f"{TRANSFORM_DIR}/{transform_filename}"

    subprocess.check_call(f"mkdir -p {TRANSFORM_DIR}".split(' '))
    # if doesnt exist
    s3_client.download_file(Bucket=transform_bucket, Key=transform_key, Filename=NODE_FILE_PATH)
    ipfs_add = f'ipfs add {NODE_FILE_PATH}'.split(' ')
    [ipfs_action, cid, _file_name] = subprocess.check_output(ipfs_add).decode('ascii').replace('\n', '').split(' ')

    ipfs_id = open(f'{IPFS_DIR}/ipfs_id.json')
    ipfs_addresses = json.load(ipfs_id)["Addresses"]
    ip4_tcp_addresses = [x for x in ipfs_addresses if ('tcp' in x) and ('ip4' in x) and ('127.0.0.1' not in x)]

    partial_bom = {
        'action': ipfs_action,
        'transform_cid': cid,
        'transform_uri': transform_uri,
        'transformer_addresses': ip4_tcp_addresses,
        'transform_filename': transform_filename,
        'transform_node_path': NODE_FILE_PATH
    }
    return partial_bom

def save_bom(bom_type: str = 'cao'):
    BOM_DIR = f"{WORK_DIR}/job/bom"
    BOM_FILE = f'{BOM_DIR}/{bom_type}_bom.json'
    def f(partial_bom):
        subprocess.check_call(f"mkdir -p {BOM_DIR}".split(' '))
        with open(BOM_FILE, 'w') as fp:
            json.dump(partial_bom, fp)
        ipfs_add = f'ipfs add {BOM_FILE}'.split(' ')
        [_, bom_cid, _file_name] = subprocess.check_output(ipfs_add).decode('ascii').replace('\n', '').split(' ')
        partial_bom['cad_cid'] = bom_cid
        return partial_bom
    return f


# Ingest
def cad_part_invoice(cad_part_id_dict):
    bucket = 'cats-public'
    file_path_key = cad_part_id_dict["FilePathKey"]
    file_name = file_path_key.split('/')[-1]
    NODE_FILE_PATH = f"{WORK_DIR}/job/{file_path_key}"
    ipfs_addresses = cad_part_id_dict["Addresses"]
    ip4_tcp_addresses = [x for x in ipfs_addresses if ('tcp' in x) and ('ip4' in x) and ('127.0.0.1' not in x)]

    INPUT = f"{WORK_DIR}/job/input/df"
    OUTPUT = f"{WORK_DIR}/job/output/df"
    subprocess.check_call(f"mkdir -p {INPUT}".split(' '))
    subprocess.check_call(f"mkdir -p {OUTPUT}".split(' '))
    if '/job/input/df' in NODE_FILE_PATH:
        s3_client.download_file(Bucket=bucket, Key=file_path_key, Filename=NODE_FILE_PATH)  # delete after transfer
        ipfs_add = f'ipfs add {INPUT}/{file_name}'.split(' ')
    else:
        NODE_FILE_PATH = f"{OUTPUT}/{file_name}"
        s3_client.download_file(Bucket=bucket, Key=file_path_key, Filename=NODE_FILE_PATH)
        ipfs_add = f'ipfs add {OUTPUT}/{file_name}'.split(' ')
    [ipfs_action, cid, _file_name] = subprocess.check_output(ipfs_add).decode('ascii').replace('\n', '').split(' ')

    return {
        'cid': cid,
        'addresses': ip4_tcp_addresses,
        'filename': file_name,
        'action': ipfs_action,
        'file_key': file_path_key
    }

def link_ipfs_id(file_path_key):
    ipfs_id = open(f'{IPFS_DIR}/ipfs_id.json')
    cad_part_id_dict = json.load(ipfs_id)
    cad_part_id_dict["FilePathKey"] = file_path_key

    return cad_part_id_dict

def ipfs_caching(file_path_key):
    return cad_part_invoice(link_ipfs_id(file_path_key))