import os

import boto3

s3_client = boto3.client(
    's3',
    region_name='us-east-2',
    aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
    aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY')
)
s3_resource = boto3.resource(
    's3',
    aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
    aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY')
)
session = boto3.Session(
    region_name='us-east-2',
    aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
    aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY')
)

def get_s3_keys(bucket, part_path):
    """Get a list of keys in an S3 bucket."""
    keys = []
    # resp = s3.list_objects_v2(Bucket=bucket, Prefix='input/df/')
    resp = s3_client.list_objects_v2(Bucket=bucket, Prefix=part_path)
    for obj in resp['Contents']:
        keys.append(obj['Key'])
    if part_path in keys:
        keys.remove(part_path)
    return keys