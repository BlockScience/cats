import boto3, os, subprocess, json
from pandas import DataFrame
from pyspark import RDD
from pyspark.sql import SparkSession
#
# spark = SparkSession \
#         .builder \
#         .appName("sparkCAT") \
#         .getOrCreate()
# sc = spark.sparkContext







