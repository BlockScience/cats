from __future__ import print_function # Only Python 2.x
import os, subprocess

spark_submit_str = """
aws s3 cp $CATS/pycats/apps/transform.py s3://cats-public/cad-store/cad/transformation/transform.py
pip3 install -r requirements.txt
python3 setup.py sdist bdist_wheel
pip3 install dist/*.whl --force-reinstall
venv-pack -o venv.tar.gz --force
$SPARK_HOME/bin/spark-submit \
--master k8s://https://192.168.49.2:8443 \
--name spark-pi \
--conf spark.executor.instances=2 \
--conf spark.executor.memory=2g \
--conf spark.kubernetes.container.image=pyspark/spark-py:latest \
--conf spark.kubernetes.container.image.pullPolicy=Never \
--conf spark.kubernetes.authenticate.driver.serviceAccountName=spark \
--conf spark.kubernetes.executor.deleteOnTermination=true \
--conf spark.kubernetes.executor.secrets.aws-access=/etc/secrets \
--conf spark.kubernetes.executor.secretKeyRef.AWS_ACCESS_KEY_ID=aws-access:AWS_ACCESS_KEY_ID \
--conf spark.kubernetes.executor.secretKeyRef.AWS_SECRET_ACCESS_KEY=aws-access:AWS_SECRET_ACCESS_KEY \
--packages com.amazonaws:aws-java-sdk:1.11.375 \
--packages org.apache.hadoop:hadoop-aws:3.2.0 \
--conf spark.kubernetes.file.upload.path=s3a://cats-storage/input/ \
--conf spark.hadoop.fs.s3a.access.key=AKIA33POLW37JRLPOZ64 \
--conf spark.hadoop.fs.s3a.impl=org.apache.hadoop.fs.s3a.S3AFileSystem \
--conf spark.hadoop.fs.s3a.fast.upload=true \
--conf spark.hadoop.fs.s3a.secret.key=fDX0Bbt7IlUsjZE4ATgwxvTm/6oFVA+T0zNP1m5z \
--conf spark.driver.extraJavaOptions="-Divy.cache.dir=/tmp -Divy.home=/tmp" \
--conf spark.pyspark.driver.python=/home/jjodesty/Projects/Research/cats/venv/bin/python \
--archives venv.tar.gz#environment file:///home/jjodesty/Projects/Research/cats/pycats/apps/cat.py
"""
spark_submit_cmds = [i.split(' ') for i in spark_submit_str.split("\n") if i]

os.chdir("/home/jjodesty/Projects/Research/cats")
proc = subprocess.Popen(
   "aws s3 cp $CATS/pycats/apps/transform.py s3://cats-public/cad-store/cad/transformation/transform.py".split(' '),
   stdout=subprocess.PIPE,
   env={
      'CATS': '$HOME/Projects/Research/cats',
      'SPARK_HOME': '/usr/local/spark',
      'PYSPARK_DRIVER_PYTHON': 'python',
      'PYSPARK_PYTHON': './environment/bin/python'
   }
)

# def execute(cmd):
#     popen = subprocess.Popen(cmd, stdout=subprocess.PIPE, universal_newlines=True)
#     for stdout_line in iter(popen.stdout.readline, ""):
#         yield stdout_line
#     popen.stdout.close()
#     return_code = popen.wait()
#     if return_code:
#         raise subprocess.CalledProcessError(return_code, cmd)
#
#
#
# # Example
# for path in execute(spark_submit_cmds[0]):
#  print(path, end="")

# with subprocess.Popen(spark_submit_cmds[0], stdout=subprocess.PIPE, bufsize=1, universal_newlines=True) as p:
#    for line in p.stdout:
#       print(line, end='')  # process line here
#
# if p.returncode != 0:
#    raise subprocess.CalledProcessError(p.returncode, p.args)

# process=subprocess.Popen(spark_submit_str,stdout=subprocess.PIPE,stderr=subprocess.PIPE, universal_newlines=True, shell=True)
# stdout,stderr = process.communicate()
# if process.returncode != 0:
#    print(stderr)
# print(stdout)