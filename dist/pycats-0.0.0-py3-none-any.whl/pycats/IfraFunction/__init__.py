from __future__ import print_function # Only Python 2.x
import os, subprocess


def execute(cmd):
    env_vars = os.environ.copy()
    env_vars['PYSPARK_DRIVER_PYTHON'] = 'python'
    env_vars['PYSPARK_PYTHON'] = './environment/bin/python'
    popen = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        # stderr=subprocess.PIPE,
        universal_newlines=True,
        env=env_vars,
        shell=True
    )
    for stdout_line in iter(popen.stdout.readline, ""):
        yield stdout_line
    popen.stdout.close()
    return_code = popen.wait()
    if return_code:
        # _, stderr = popen.communicate()
        # print(stderr)
        raise subprocess.CalledProcessError(return_code, cmd)

def build_cat(CATS_HOME):
    build_block = f"""
    pip3 install -r requirements.txt
    python3 setup.py sdist bdist_wheel
    pip3 install dist/pycats-0.0.0-py3-none-any.whl --force-reinstall
    venv-pack -o venv.tar.gz --force
    aws s3 cp {CATS_HOME}/pycats/apps/transform.py s3://cats-public/cad-store/cad/transformation/transform.py
    """
    build_cmds = [i for i in build_block.split("\n") if i]
    for cmd in build_cmds:
        for path in execute(cmd):
            print(path, end="")
    return build_cmds

def spark_submit(SPARK_HOME, CAT_APP_HOME):
    spark_submit_block = f"""
    {SPARK_HOME}/bin/spark-submit \
    --packages com.amazonaws:aws-java-sdk:1.11.375 \
    --packages org.apache.hadoop:hadoop-aws:3.2.0 \
    --archives venv.tar.gz#environment file://{CAT_APP_HOME}
    """
    spark_submit_cmds = [i for i in spark_submit_block.split("\n") if i]
    for cmd in spark_submit_cmds:
        for path in execute(cmd):
            print(path, end="")
    return spark_submit_cmds

HOME = '/home/jjodesty'
SPARK_HOME = '/usr/local/spark'
CATS_HOME = f'{HOME}/Projects/Research/cats'
CAT_APP_HOME = f"{HOME}/Projects/Research/cats/pycats/apps/cat.py"
build_cat(CATS_HOME)
spark_submit(SPARK_HOME, CAT_APP_HOME)