import os

CATS_HOME = os.getenv('CATS_HOME')

