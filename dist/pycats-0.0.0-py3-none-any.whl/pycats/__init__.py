# WORK_DIR = '/opt/spark/work-dir'
# IPFS_DIR = f'{WORK_DIR}/ipfs'
# IPFS_COMPUTE = f"{IPFS_DIR}/ipfs-compute"
# GO_IPFS = f"{IPFS_DIR}/go-ipfs"
# IPFS_SCRIPTS = f"{WORK_DIR}/job/scripts"
# GO_IPFS_CONFIG = f"{IPFS_DIR}/.ipfs"
# GO_IPFS_DEAMON = f"{IPFS_DIR}/ipfs_deamon_running.sh"
# INPUT = f"{WORK_DIR}/job/input/df"

