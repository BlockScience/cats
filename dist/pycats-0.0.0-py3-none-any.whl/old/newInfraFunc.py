from __future__ import print_function # Only Python 2.x

import os
import subprocess

# os.chdir("/home/jjodesty/Projects/Research/cats")

HOME = '/home/jjodesty'
CATS = f'{HOME}/Projects/Research/cats'
build_str = f"""
pip3 install -r requirements.txt
python3 setup.py sdist bdist_wheel
pip3 install dist/pycats-0.0.0-py3-none-any.whl --force-reinstall
venv-pack -o venv.tar.gz --force
aws s3 cp {CATS}/pycats/apps/transform.py s3://cats-public/cad-store/cad/transformation/transform.py
"""
build_cmds = [i for i in build_str.split("\n") if i]

SPARK_HOME = '/usr/local/spark'
# spark_submit_str = f"""
# {SPARK_HOME}/bin/spark-submit \
# --master k8s://https://192.168.49.2:8443 \
# --name spark-pi \
# --conf spark.executor.instances=2 \
# --conf spark.executor.memory=2g \
# --conf spark.kubernetes.container.image=pyspark/spark-py:latest \
# --conf spark.kubernetes.container.image.pullPolicy=Never \
# --conf spark.kubernetes.authenticate.driver.serviceAccountName=spark \
# --conf spark.kubernetes.executor.deleteOnTermination=true \
# --conf spark.kubernetes.executor.secrets.aws-access=/etc/secrets \
# --conf spark.kubernetes.executor.secretKeyRef.AWS_ACCESS_KEY_ID=aws-access:AWS_ACCESS_KEY_ID \
# --conf spark.kubernetes.executor.secretKeyRef.AWS_SECRET_ACCESS_KEY=aws-access:AWS_SECRET_ACCESS_KEY \
# --packages com.amazonaws:aws-java-sdk:1.11.375 \
# --packages org.apache.hadoop:hadoop-aws:3.2.0 \
# --conf spark.hadoop.fs.s3a.access.key=AKIA33POLW37JRLPOZ64 \
# --conf spark.hadoop.fs.s3a.secret.key=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 \
# --conf spark.kubernetes.file.upload.path=s3a://cats-storage/input/ \
# --conf spark.hadoop.fs.s3a.impl=org.apache.hadoop.fs.s3a.S3AFileSystem \
# --conf spark.hadoop.fs.s3a.fast.upload=true \
# --conf spark.driver.extraJavaOptions='-Divy.cache.dir=/tmp -Divy.home=/tmp' \
# --conf spark.pyspark.driver.python=/home/jjodesty/Projects/Research/cats/venv/bin/python \
# --archives venv.tar.gz#environment file:///home/jjodesty/Projects/Research/cats/pycats/apps/cat.py
# """
spark_submit_str = f"""
{SPARK_HOME}/bin/spark-submit \
--packages com.amazonaws:aws-java-sdk:1.11.375 \
--packages org.apache.hadoop:hadoop-aws:3.2.0 \
--archives venv.tar.gz#environment file:///home/jjodesty/Projects/Research/cats/pycats/apps/cat.py
"""
spark_submit_cmds = [i for i in spark_submit_str.split("\n") if i]

env_vars = os.environ.copy()
env_vars['PYSPARK_DRIVER_PYTHON'] = 'python'
env_vars['PYSPARK_PYTHON'] = './environment/bin/python'
def execute(cmd):
    popen = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        # stderr=subprocess.PIPE,
        universal_newlines=True,
        env=env_vars,
        shell=True
    )
    for stdout_line in iter(popen.stdout.readline, ""):
        yield stdout_line
    popen.stdout.close()
    return_code = popen.wait()
    if return_code:
        # _, stderr = popen.communicate()
        # print(stderr)
        raise subprocess.CalledProcessError(return_code, cmd)




# for cmd in build_cmds:
#     for path in execute(cmd):
#         print(path, end="")

for cmd in spark_submit_cmds:
    for path in execute(cmd):
        print(path, end="")

# with subprocess.Popen(spark_submit_cmds[0], stdout=subprocess.PIPE, bufsize=1, universal_newlines=True) as p:
#    for line in p.stdout:
#       print(line, end='')  # process line here
# #
# if p.returncode != 0:
#    raise subprocess.CalledProcessError(p.returncode, p.args)

# process=subprocess.Popen(spark_submit_str,stdout=subprocess.PIPE,stderr=subprocess.PIPE, universal_newlines=True, shell=True)
# stdout,stderr = process.communicate()
# if process.returncode != 0:
#    print(stderr)
# print(stdout)