import json
import os, time, boto3
import subprocess
from pprint import pprint

from pyspark import RDD
from pyspark.sql import SparkSession, DataFrame

spark = SparkSession \
        .builder \
        .appName("sparkCAT") \
        .getOrCreate()
spark.sparkContext.setLogLevel("OFF")
sc = spark.sparkContext
sc.setLogLevel("OFF")
# WORK_DIR = '/opt/spark/work-dir'
# IPFS_DIR = f'{WORK_DIR}/ipfs'
# INPUT = f"{WORK_DIR}/job/input/df"
# bc_WORK_DIR = sc.broadcast(WORK_DIR)
# bc_IPFS_DIR = sc.broadcast(IPFS_DIR)
# bc_INPUT = sc.broadcast(INPUT)

s3 = boto3.client(
        's3',
        region_name='us-east-2',
        aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY')
    )


def get_s3_keys(bucket, part_path):
    """Get a list of keys in an S3 bucket."""
    keys = []
    # resp = s3.list_objects_v2(Bucket=bucket, Prefix='input/df/')
    resp = s3.list_objects_v2(Bucket=bucket, Prefix=part_path)
    for obj in resp['Contents']:
        keys.append(obj['Key'])
    # keys.remove('input/df/')
    return keys

# s3_out_put_keys = get_s3_keys('cats-public')
# pprint(s3_out_put_keys)
# exit()

def get_ipfs_id(file_path_key):
    import json
    WORK_DIR = '/opt/spark/work-dir'
    IPFS_DIR = f'{WORK_DIR}/ipfs'
    ipfs_id = open(f'{IPFS_DIR}/ipfs_id.json')
    cad_part_id_dict = json.load(ipfs_id)
    cad_part_id_dict["FilePathKey"] = file_path_key

    return cad_part_id_dict


def ipfs_connect(cad_part_invoice):
    addresses = cad_part_invoice['addresses']
    for address in addresses:
        output = subprocess.check_output(f"ipfs swarm connect {address}".split(' ')) \
            .decode('ascii').replace('\n', '').split(' ')
        if output[2] == 'success':
            cad_part_invoice['connection'] = address
        else:
            cad_part_invoice['connection'] = None
        return cad_part_invoice


def s3_ingest(cad_part_invoice):
    import boto3
    s3 = boto3.client(
        's3',
        region_name='us-east-2',
        aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY')
    )
    WORK_DIR = '/opt/spark/work-dir'
    INPUT = f"{WORK_DIR}/job/input/df"


    cid = cad_part_invoice['cid']
    filename = cad_part_invoice['filename']
    bucket = 'cats-public'
    key = 'cad-store/cad/cai/parts'
    uri = f's3a://{bucket}/{key}'
    subprocess.check_call(f"mkdir -p {INPUT}".split(' '))

    os.chdir(INPUT)
    output = subprocess.check_output(f"ipfs get {cid}".split(' ')).decode('ascii').replace('\n', '')
    if output == f'Saving file(s) to {cid}':
        subprocess.check_call(f"mv {cid} {filename}".split(' '))
        try:
            file = open(filename, "rb")
            s3.upload_fileobj(file, Bucket=bucket, Key=key)
            cad_part_invoice['upload_path'] = uri
            return cad_part_invoice
        except Exception as e:
            cad_part_invoice['upload_path'] = str(e)
            return cad_part_invoice


def cluster_fs_ingest(cad_part_invoice):
    return s3_ingest(ipfs_connect(cad_part_invoice))


def get_upload_path(cad_part_invoice):
    return str(cad_part_invoice['upload_path'])


def output_CAD(cad_part_id_dict):
    import boto3
    s3 = boto3.client(
        's3',
        region_name='us-east-2',
        aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY')
    )

    WORK_DIR = '/opt/spark/work-dir'
    OUTPUT = f"{WORK_DIR}/job/output/df"

    bucket = 'cats-public'
    file_path_key = cad_part_id_dict["FilePathKey"]
    file_name = file_path_key.split('/')[-1]
    output_key = f'cad-store/cad/cao/parts/{file_name}'
    cad_part_id_dict["output_key"] = output_key
    node_storage_key = f'output/df/{file_name}'
    NODE_FILE_PATH = f"{WORK_DIR}/job/{node_storage_key}"
    ipfs_addresses = cad_part_id_dict["Addresses"]
    ip4_tcp_addresses = [x for x in ipfs_addresses if ('tcp' in x) and ('ip4' in x) and ('127.0.0.1' not in x)]

    subprocess.check_call(f"mkdir -p {OUTPUT}".split(' '))
    s3.download_file(Bucket=bucket, Key=output_key, Filename=NODE_FILE_PATH)
    ipfs_add = f'ipfs add {OUTPUT}/{file_name}'.split(' ')
    [ipfs_action, cid, _file_name] = subprocess.check_output(ipfs_add).decode('ascii').replace('\n', '').split(' ')

    return {
        'cid': cid,
        'addresses': ip4_tcp_addresses,
        'filename': file_name,
        'action': ipfs_action,
        'file_key': output_key
    }


def cad_invoicing(file_path_key):
    return output_CAD(get_ipfs_id(file_path_key))

# part invoices cat level
# load
def get_part_invoices(uri, map_func=json.loads):
    return sc.textFile(uri).map(map_func)


# def transform(spark, cai_columns, cad_path):
#     add_row_vals = ' + '.join(cai_columns)
#     sql_a = f"""
#         SELECT
#             BOOLEAN(INT(({add_row_vals}) % 2)) AS row_sum_odd_ind,
#             ({add_row_vals}) AS row_sum,
#             *
#         FROM parquet.`{cad_path}`
#         WHERE _c0 != 'A'
#     """
#     trans_1 = spark.sql(sql_a)
#     trans_1.createOrReplaceTempView("trans_1")
#     trans_2_aggs = ', '.join(list(map(lambda c: f'SUM({c}) AS {c}_sum', ['row_sum'] + cai_columns)))
#     trans_2_sql = f"""
#         SELECT
#             {trans_2_aggs}
#         FROM trans_1
#         GROUP BY row_sum_odd_ind
#     """
#     cao = spark.sql(trans_2_sql)
#     return cao




# cadProc:
class CAD(object): # CAD invoice of partition transactions
    def __init__(self,
                spark: SparkSession,
                cai_invoices: RDD = None,
                cai_ingest_func = lambda part_invoice: cluster_fs_ingest(json.loads(part_invoice))
            ):
        self.spark: SparkSession = spark
        self.cai_invoices: RDD = cai_invoices
        self.cai_data_uri: str = None # remove from CAD
        self.cai_ingest_func = cai_ingest_func
        self.cai_transform_func = None
        self.cai = None
        self.cao = None
        # self.cao_data_uri: str = None # remove from CAD

    def read(self, cai_invoice_uri=None):
        if cai_invoice_uri is not None:
            self.cai_invoices = sc.textFile(cai_invoice_uri).map(self.cai_ingest_func)
        self.cai_data_uri = self.cai_invoices.map(get_upload_path).distinct().collect()[0]
        self.cai = spark.input.parquet(self.cai_data_uri)
        # cai_data_uri = self.cai_invoices.map(get_upload_path).distinct().collect()[0]
        # self.cai = spark.read.parquet(cai_data_uri)
        return self

    def transform(self, cai_transform_func, cai_invoice_uri=None):
        self.cai_transform_func = cai_transform_func
        if self.cai is None and cai_invoice_uri is None:
            self.read()
        elif cai_invoice_uri is not None:
            self.read(cai_invoice_uri)
        self.cao = self.cai_transform_func(self)
        return self

    def write(self, cao_data_uri):
        self.cao.write.parquet(cao_data_uri, mode='overwrite')
        # self.cao_data_uri = cao_data_uri
        # self.cao.write.parquet(self.cao_data_uri, mode='overwrite')

    def execute(self, cai_transform_func, cao_data_uri):
        self.read()
        self.transform(cai_transform_func)
        self.write(cao_data_uri)
        return self

# ToDo What from where / unified defenition
# ToDo CAT as extenstion of CAD
# ToDo delete job data after transfer
# ToDo CAP: Content Addressable Pipeline
class CAT(object):
    def __init__(self, cai_uri: str, cao_uri: str, sparkSession: SparkSession):
        self.cai_uri: str = cai_uri
        self.cao_uri: str = cao_uri
        self.spark: SparkSession = sparkSession # extend from CAD
        self.sc = self.spark.sparkContext
        self.sc._jsc. \
            hadoopConfiguration().set("mapreduce.input.fileinputformat.input.dir.recursive", "true")

        self.cai_data_uri: str = None # Extend from CAD
        self.cao_data_uri: str = f'{self.cao_uri}/parts'  # remove from CAD
        self.cai_invoice_uri: str = f'{self.cai_uri}/invoices'  # transactions
        self.cao_invoice_uri: str = f'{self.cao_uri}/invoices'

        self.cao_bucket = self.cao_data_uri.split('s3a://')[-1].split('/')[0]
        self.cao_data_dir = self.cao_data_uri.split('cats-public/')[-1]

        self.cai_ingest_func = lambda part_invoice: cluster_fs_ingest(json.loads(part_invoice)) # extend from CAD
        # self.cai_ingest_func = lambda part_invoice: json.loads(part_invoice)  # extend from CAD
        self.cai_transform_func = None

        self.cai_invoices = sc.textFile(self.cai_invoice_uri).map(self.cai_ingest_func) # transactions
        # pprint(self.cai_invoices.collect())
        # while True:
        #     time.sleep(1)

        self.cad: CAD = CAD(self.spark, self.cai_invoices).read()
        # self.caoCAD: CAD = None
        self.cai: DataFrame = None # extend from CAD
        self.cao: DataFrame = None # extend from CAD
        self.caiInvoice: RDD = None
        self.caoInvoice: RDD = None

    def transform(self, cai_transform_func):
        self.cai_transform_func = cai_transform_func
        self.cad = self.cad.transform(cai_transform_func)
        self.cai = self.cad.cai
        self.cao = self.cad.cao
        self.cai_data_uri = self.cad.cai_data_uri
        self.caiInvoice: RDD = self.cad.cai_invoices
        s3_out_put_keys = get_s3_keys(self.cao_bucket, self.cao_data_dir)
        partition_count = len(s3_out_put_keys)
        self.caoInvoice: RDD = spark.sparkContext \
            .parallelize(s3_out_put_keys) \
            .repartition(partition_count) \
            .map(cad_invoicing)
        return {
            'cai': self.cai,
            'cai_invoice': self.caiInvoice,
            'cao': self.cao,
            'cao_invoice': self.caoInvoice
        }

    def execute(self, cai_transform_func):
        if self.cai is None \
                and self.caiInvoice is None \
                and self.cao is None \
                and self.cai_transform_func is None:
            self.cai_transform_func = cai_transform_func
            self.cad = self.cad.execute(self.cai_transform_func, self.cao_data_uri)
            self.cai_data_uri = self.cad.cai_data_uri
            self.caiInvoice: RDD = self.cad.cai_invoices
            self.cai = self.cad.cai
            self.cao = self.cad.cao
        else:
            if self.cai is None or self.caiInvoice is None:
                self.cad = self.cad.input()
                self.cai = self.cad.cai
                self.cai_data_uri = self.cad.cai_data_uri
                self.caiInvoice: RDD = self.cad.ingested_invoices
            if self.cao is None or self.cai_transform_func is None:
                self.cai_transform_func = cai_transform_func
                self.cao = self.cad.transform(self.cai_transform_func).cao
                self.cad.write(self.cao_data_uri)
        if self.caoInvoice is None:
            s3_out_put_keys = get_s3_keys(self.cao_bucket, self.cao_data_dir)
            partition_count = len(s3_out_put_keys)
            self.caoInvoice: RDD = spark.sparkContext \
                .parallelize(s3_out_put_keys) \
                .repartition(partition_count) \
                .map(cad_invoicing)
            self.caoInvoice.toDF().write.json(self.cao_invoice_uri, mode='overwrite')
        return {
            'cai': self.cai,
            'cai_invoice': self.caiInvoice,
            'cao': self.cao,
            'cao_invoice': self.caoInvoice
        }


if __name__ == "__main__":
    cat = CAT(
        cai_uri='s3a://cats-public/cad-store/cad/cai',
        cao_uri='s3a://cats-public/cad-store/cad/cao',
        sparkSession=spark,
        # plant=???
        # cai_transform_func=transform
    )


    def transform(cad):
        columns = cad.cai.columns
        add_row_vals = ' + '.join(columns)
        sql_a = f"""
            SELECT
                BOOLEAN(INT(({add_row_vals}) % 2)) AS row_sum_odd_ind,
                ({add_row_vals}) AS row_sum,
                *
            FROM parquet.`{cad.cai_data_uri}`
            WHERE _c0 != 'A'
        """
        trans_1 = cad.spark.sql(sql_a)
        trans_1.createOrReplaceTempView("trans_1")
        trans_2_aggs = ', '.join(list(map(lambda c: f'SUM({c}) AS {c}_sum', ['row_sum'] + columns)))
        trans_2_sql = f"""
            SELECT
                {trans_2_aggs}
            FROM trans_1
            GROUP BY row_sum_odd_ind
        """
        cao = cad.spark.sql(trans_2_sql)
        return cao

    cad_dict = cat.execute(cai_transform_func=transform)
    cai_invoice = cat.caiInvoice.collect()
    cao_invoice = cat.caoInvoice.collect()
    cat.cai.show()
    pprint(cai_invoice)
    cat.cao.show()
    pprint(cao_invoice)

    # cad = CAD(spark)
    # t = transform
    # cao = cad.transform(t, 's3a://cats-public/cad-store/cad/cai/invoices').cao
    # cao.show()

    while True:
        time.sleep(1)

    spark.stop()

# if __name__ == "__main__":
#     uri = 's3a://cats-public/cad-store/cad/cai'
#     caiCAD = CAD(uri, spark)
#     cai = caiCAD.read()
#     # cad_path = cad.cad_path
#     cao = transform(cai.columns, caiCAD.input_data_uri)
#     cao_path = 's3a://cats-public/cad-store/cad/cao/parts'
#     cao.write.parquet(cao_path, mode='overwrite')
#     # cai.show()
#     # pprint(cad.ingested_invoices.collect())
#     # exit()
#
#     while True:
#         time.sleep(1)
#
#     spark.stop()


gg = None
# if __name__ == "__main__":
#     """
#         Usage: CAT
#     """
#
#     # Sub Transformation using IPFS Compute
#     # CAD Ingest
#     cad_part_invoices = sc.textFile('s3a://cats-public/cad-store/cad/cai/invoices').map(json.loads)
#     cad_ingest_invoice = cad_part_invoices.map(cluster_fs_ingest)
#     # pprint(cad_ingest_invoice.collect())
#
#     # dCAD instantiation
#     cad_path = cad_ingest_invoice.map(get_upload_path).distinct().collect()[0]
#     cai = spark.read.parquet(cad_path)
#     # # pyspark.sql.utils.AnalysisException: Path does not exist: s3a://cats-public/cad-store/cad/cai/parts
#
#
#     # dCAD.printSchema()
#     # dCAD.show()
#     # pprint(dCAD.columns)
#
#
#
#
#     cao = transform(cai.columns, cad_path)
#     cao_path = 's3a://cats-public/cad-store/cad/cao/parts'
#     cao.write.parquet(cao_path, mode='overwrite')
#     s3_out_put_keys = get_s3_keys('cats-public')
#     # pprint(s3_out_put_keys)
#
#     executor_count = 2
#     partition_count = len(s3_out_put_keys)
#     cao_invoice: DataFrame = spark.sparkContext \
#         .parallelize(s3_out_put_keys) \
#         .repartition(partition_count) \
#         .map(cad_invoicing)
#
#     cao_invoice_df = cao_invoice.toDF()
#     cao_invoice_df.write.json('s3a://cats-public/cad-store/cad/cao/invoices', mode='overwrite')
#     cao_invoice_df.show()
#     # pprint(cao_invoice.collect())
#     cao.show()
#     # cad_output_invoice = cad_ingest_invoice.map(output_CAD)
#     # pprint(cad_output_invoice.collect())
#
#     while True:
#         time.sleep(1)
#
#     spark.stop()
