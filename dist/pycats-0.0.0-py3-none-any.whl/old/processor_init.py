import json
import os
import subprocess
# from multimethod import multimethod
import sys
import time
from types import FunctionType

from multimethod import isa, overload

from pyspark import RDD
from pyspark.sql import SparkSession, DataFrame
from pycats.processor.utils import cluster_fs_ingest, get_upload_path, get_s3_keys, cad_invoicing, s3, ipfs_caching, \
    content_address_tranformer


# class CAD(object): # CAD invoice of partition transactions
#     def __init__(self,
#         spark: SparkSession,
#         cai_invoices: RDD = None,
#         cai_ingest_func = lambda part_invoice: cluster_fs_ingest(json.loads(part_invoice))
#     ):
#         self.spark: SparkSession = spark
#         self.sc = spark.sparkContext
#         self.cai_invoices: RDD = cai_invoices
#         self.cai_data_uri: str = None # remove from CAD
#         self.cai_ingest_func = cai_ingest_func
#         self.cai_transform_func = None
#         self.cai = None
#         self.cao = None
#
#     def read(self, cai_invoice_uri=None):
#         if cai_invoice_uri is not None:
#             self.cai_invoices = self.sc.textFile(cai_invoice_uri).map(self.cai_ingest_func)
#         self.cai_data_uri = self.cai_invoices.map(get_upload_path).distinct().collect()[0]
#         self.cai = self.spark.read.parquet(self.cai_data_uri)
#         return self
#
#     def transform(self, cai_transform_func, cai_invoice_uri=None):
#         self.cai_transform_func = cai_transform_func
#         if self.cai is None and cai_invoice_uri is None:
#             self.read()
#         elif cai_invoice_uri is not None:
#             self.read(cai_invoice_uri)
#         self.cao = self.cai_transform_func(self)
#         return self
#
#     def write(self, cao_data_uri):
#         self.cao.write.parquet(cao_data_uri, mode='overwrite')
#
#     def execute(self, cai_transform_func, cao_data_uri):
#         self.read()
#         self.transform(cai_transform_func)
#         self.write(cao_data_uri)
#         return self


# class CAT(object):
#     def __init__(self,
#         sparkSession: SparkSession,
#         cai_uri: str = None,
#         cao_uri: str = None,
#         transformer_uri: str = None,
#         transform_path: str = None
#     ):
#         self.spark: SparkSession = sparkSession
#         self.sc = self.spark.sparkContext
#         self.sc._jsc. \
#             hadoopConfiguration().set("mapreduce.input.fileinputformat.input.dir.recursive", "true")
#         self.cai_uri: str = cai_uri
#         self.cao_uri: str = cao_uri
#         self.transformer_uri = transformer_uri
#
#         self.cai_data_uri: str = None  # Extend from CAD
#         self.cai_invoice_uri: str = f'{self.cai_uri}/invoices'  # transactions
#
#         self.cao_data_uri: str = f'{self.cao_uri}/parts'  # remove from CAD
#         self.cao_invoice_uri: str = f'{self.cao_uri}/invoices'
#         self.cao_transform_uri: str = f'{self.cao_uri}/transformation'
#
#         self.cao_bucket = self.cao_data_uri.split('s3a://')[-1].split('/')[0]
#         self.cao_data_dir = self.cao_data_uri.split('cats-public/')[-1]
#         self.cao_transform_dir = self.cao_transform_uri.split('cats-public/')[-1]
#         self.transform_func = None
#
#         self.cai: DataFrame = None
#         self.cao: DataFrame = None
#         self.caiInvoice: RDD = None
#         self.caoInvoice: RDD = None
#
#         # if transformer_path is not None:
#         #     if 's3a://' in transformer_path:
#         #         print()
#         #     else:
#         #         self.transformer_path = transformer_path
#         #         transform_file = open(self.transformer_path, "rb")
#         #         self.transform_filename = self.transformer_path.split('/')[-1]
#         #         self.transform_key = f"{self.cao_transform_dir}/{self.transform_filename}"
#         #         # self.transform_uri =
#         #         s3.upload_fileobj(transform_file, Bucket='cats-public', Key=self.transform_key)
#         #         transform_file.close()
#         if cai_uri is not None or cao_uri is not None:
#             self.cai_ingest_func = lambda part_invoice: cluster_fs_ingest(json.loads(part_invoice))
#             self.cad: CAD = CAD(
#                 spark=self.spark,
#                 cai_invoices=self.sc.textFile(self.cai_invoice_uri).map(self.cai_ingest_func)
#             ).read()
#
#     def content_address_dataset(self, bucket, input_path, cad_uri):
#         s3_input_keys = get_s3_keys(bucket, input_path)
#         partition_count = len(s3_input_keys)
#         input_cad_invoice: RDD = self.sc \
#             .parallelize(s3_input_keys) \
#             .repartition(partition_count) \
#             .map(ipfs_caching)
#         input_cad_invoice_df: DataFrame = input_cad_invoice.toDF()
#         input_cad_invoice_df.write.json(f'{cad_uri}/invoices', mode='overwrite')
#         return input_cad_invoice
#
#     def content_address_transformer(self, transformer_uri=None):
#         if transformer_uri is not None:
#             self.transformer_uri = transformer_uri
#         ct: RDD = self.spark.sparkContext \
#             .parallelize([self.transformer_uri]) \
#             .repartition(1) \
#             .map(content_address_tranformer)
#         return ct
#
#     def content_address_input(self, bucket, input_path, cai_uri=None):
#         if cai_uri is not None:
#             self.cai_uri = cai_uri
#         return self.content_address_dataset(bucket, input_path, self.cai_uri)
#
#     def transform(self, transform_func):
#         self.transform_func = transform_func
#         self.cad = self.cad.transform(transform_func)
#         self.cai = self.cad.cai
#         self.cao = self.cad.cao
#         self.cai_data_uri = self.cad.cai_data_uri
#         self.caiInvoice: RDD = self.cad.cai_invoices
#         s3_out_put_keys = get_s3_keys(self.cao_bucket, self.cao_data_dir)
#         partition_count = len(s3_out_put_keys)
#         self.caoInvoice: RDD = self.spark.sparkContext \
#             .parallelize(s3_out_put_keys) \
#             .repartition(partition_count) \
#             .map(cad_invoicing)
#         return {
#             'cai': self.cai,
#             'cai_invoice': self.caiInvoice,
#             'cao': self.cao,
#             'cao_invoice': self.caoInvoice
#         }
#
#     def execute(self, transform_func):
#         if self.cai is None \
#                 and self.caiInvoice is None \
#                 and self.cao is None \
#                 and self.transform_func is None:
#             self.transform_func = transform_func
#             self.cad = self.cad.execute(self.transform_func, self.cao_data_uri)
#             self.cai_data_uri = self.cad.cai_data_uri
#             self.caiInvoice: RDD = self.cad.cai_invoices
#             self.cai = self.cad.cai
#             self.cao = self.cad.cao
#         else:
#             if self.cai is None or self.caiInvoice is None:
#                 self.cad = self.cad.read()
#                 self.cai = self.cad.cai
#                 self.cai_data_uri = self.cad.cai_data_uri
#                 self.caiInvoice: RDD = self.cad.ingested_invoices
#             if self.cao is None or self.transform_func is None:
#                 self.transform_func = transform_func
#                 self.cao = self.cad.transform(self.transform_func).cao
#                 self.cad.write(self.cao_data_uri)
#         if self.caoInvoice is None:
#             s3_out_put_keys = get_s3_keys(self.cao_bucket, self.cao_data_dir)
#             partition_count = len(s3_out_put_keys)
#             self.caoInvoice: RDD = self.spark.sparkContext \
#                 .parallelize(s3_out_put_keys) \
#                 .repartition(partition_count) \
#                 .map(cad_invoicing)
#             self.caoInvoice.toDF().write.json(self.cao_invoice_uri, mode='overwrite')
#         return {
#             'cai': self.cai,
#             'cai_invoice': self.caiInvoice,
#             'cao': self.cao,
#             'cao_invoice': self.caoInvoice
#         }


class CAD(object):  # CAD invoice of partition transactions
    def __init__(self,
                 spark: SparkSession,
                 df: DataFrame = None,
                 cai_ingest_func=lambda part_invoice: cluster_fs_ingest(json.loads(part_invoice))
                 ):
        self.spark: SparkSession = spark
        self.sc = spark.sparkContext
        self.cai_ingest_func = cai_ingest_func
        self.transformer_uri = None
        self.transform_func = None
        self.catContext: dict = None

        self.invoiceURI = None
        self.invoice = None
        self.bom = None
        self.df = df

    @overload
    def read(self, invoice: isa(RDD)):
        data_uri = invoice.map(get_upload_path).distinct().collect()[0]
        # get cai_invoice_uri
        df: DataFrame = self.spark.read.parquet(data_uri)
        self.catContext = {
            'cai': df,
            'cai_invoice': invoice,
            'cai_data_uri': data_uri,
        }
        return self.catContext

    @overload
    def read(self, invoice_uri: isa(str)):
        invoice = self.sc.textFile(invoice_uri).map(self.cai_ingest_func)
        self.catContext['cai_invoice_uri'] = invoice_uri
        return self.read(invoice)

    @overload
    def transform(self, transform_func, invoice_uri: isa(str) = None):
        self.transform_func = transform_func
        if self.catContext['cai'] is not None or invoice_uri is None:
            self.df = self.transform_func(self)
            self.catContext['cao'] = self.df
            return self.catContext
        elif self.catContext['cai'] is None or invoice_uri is not None:
            self.catContext = self.read(invoice_uri)
            self.df = self.transform_func(self)
            self.catContext['cao'] = self.df
            return self.catContext

    @overload
    def transform(self, transform_func: isa(FunctionType), invoice: isa(RDD) = None):
        self.transform_func = transform_func
        if self.catContext['cai'] is not None or invoice is None:
            self.df = self.transform_func(self)
            self.catContext['cao'] = self.df
            return self.catContext
        elif self.catContext['cai'] is None or invoice is not None:
            self.catContext = self.read(invoice)
            self.df = self.transform_func(self)
            self.catContext['cao'] = self.df
            return self.catContext

    def get_transform(self):
        WORK_DIR = '/opt/spark/work-dir'
        INPUT = f"{WORK_DIR}/job/input"
        TRANSFORM = f"{INPUT}/transform"
        TRANSFORM_PATH = f"{TRANSFORM}/transform.py"
        # while True:
        #     time.sleep(1)
        subprocess.check_call(f"mkdir -p {TRANSFORM}".split(' '))
        os.chdir(TRANSFORM)
        output = subprocess.check_output(f"ipfs get {self.bom['transform_cid']}".split(' ')).decode('ascii').replace(
            '\n', '')
        print(output)
        subprocess.check_call(f"mv {self.bom['transform_cid']} {self.bom['transform_filename']}".split(' '))
        sys.path.append(os.path.abspath(TRANSFORM_PATH))
        from transform import transform as transform_func
        return transform_func

    @overload
    def transform(self, transform_uri: isa(str), invoice: isa(RDD) = None):
        self.transform_func = self.get_transform()
        if self.catContext['cai'] is not None or invoice is None:
            self.df = self.transform_func(self)
            self.catContext['cao'] = self.df
            return self.catContext
        elif self.catContext['cai'] is None or invoice is not None:
            self.catContext = self.read(invoice)
            self.df = self.transform_func(self)
            self.catContext['cao'] = self.df
            return self.catContext

    def write(self, cad_data_uri: str):
        self.df.write.parquet(cad_data_uri, mode='overwrite')
        self.catContext['cao_data_uri'] = cad_data_uri

    @overload
    def execute(self, cai_invoice_uri: isa(str), cao_data_uri: isa(str), transform_func):
        self.catContext = self.read(cai_invoice_uri)
        self.transform(transform_func, cai_invoice_uri)
        self.write(cao_data_uri)
        self.catContext['cao_data_uri'] = cao_data_uri
        self.catContext['cai_invoice_uri'] = cai_invoice_uri
        self.catContext['cao_invoice_uri'] = f"{cao_data_uri.split('/parts')[0]}/invoices"
        return self.catContext

    @overload
    def execute(self, cai_invoice: isa(RDD), cao_data_uri: isa(str), transform_func):
        self.catContext = self.read(cai_invoice)
        self.transform(transform_func, cai_invoice)
        self.write(cao_data_uri)
        self.catContext['cao_data_uri'] = cao_data_uri
        # self.catContext['cai_invoice_uri'] = cai_invoice_uri
        self.catContext['cao_invoice_uri'] = f"{cao_data_uri.split('/parts')[0]}/invoices"
        return self.catContext

    def content_address_transformer(self, transformer_uri=None):
        if transformer_uri is not None:
            self.transformer_uri = transformer_uri
        bom: RDD = self.spark.sparkContext \
            .parallelize([self.transformer_uri]) \
            .repartition(1) \
            .map(content_address_tranformer) \
            .collect()[0]
        return bom


class CAT(object):
    def __init__(self,
                 sparkSession: SparkSession,
                 cai_uri: str = None,
                 cao_uri: str = None,
                 transformer_uri: str = None,
                 transform_path: str = None
                 ):
        self.spark: SparkSession = sparkSession
        self.sc = self.spark.sparkContext
        self.sc._jsc. \
            hadoopConfiguration().set("mapreduce.input.fileinputformat.input.dir.recursive", "true")
        self.cai_uri: str = cai_uri
        self.cao_uri: str = cao_uri
        self.transformer_uri = transformer_uri

        self.cai_data_uri: str = None  # Extend from CAD
        self.cai_invoice_uri: str = f'{self.cai_uri}/invoices'  # transactions

        self.cao_data_uri: str = f'{self.cao_uri}/parts'  # remove from CAD
        self.cao_invoice_uri: str = f'{self.cao_uri}/invoices'
        self.cao_transform_uri: str = f'{self.cao_uri}/transformation'

        self.cao_bucket = self.cao_data_uri.split('s3a://')[-1].split('/')[0]
        self.cao_data_dir = self.cao_data_uri.split('cats-public/')[-1]
        self.cao_transform_dir = self.cao_transform_uri.split('cats-public/')[-1]
        self.transform_func = None
        # self.transform_cid = None

        self.catContext = None
        self.bom = self.content_address_transformer(
            transformer_uri='s3a://cats-public/cad-store/cad/transformation/transform.py'
        )
        self.cai: DataFrame = None
        self.cao: DataFrame = None
        self.caiInvoice: RDD = None
        self.caoInvoice: RDD = None

        # if transformer_path is not None:
        #     if 's3a://' in transformer_path:
        #         print()
        #     else:
        #         self.transformer_path = transformer_path
        #         transform_file = open(self.transformer_path, "rb")
        #         self.transform_filename = self.transformer_path.split('/')[-1]
        #         self.transform_key = f"{self.cao_transform_dir}/{self.transform_filename}"
        #         # self.transform_uri =
        #         s3.upload_fileobj(transform_file, Bucket='cats-public', Key=self.transform_key)
        #         transform_file.close()
        if cai_uri is not None or cao_uri is not None:
            self.cai_ingest_func = lambda part_invoice: cluster_fs_ingest(json.loads(part_invoice))
            self.cad: CAD = CAD(
                spark=self.spark
            )
            self.cad.read(
                invoice=self.sc.textFile(self.cai_invoice_uri).map(self.cai_ingest_func)
            )

    def content_address_dataset(self, bucket, input_path, cad_uri):
        s3_input_keys = get_s3_keys(bucket, input_path)
        partition_count = len(s3_input_keys)
        input_cad_invoice: RDD = self.sc \
            .parallelize(s3_input_keys) \
            .repartition(partition_count) \
            .map(ipfs_caching)
        input_cad_invoice_df: DataFrame = input_cad_invoice.toDF()
        input_cad_invoice_df.write.json(f'{cad_uri}/invoices', mode='overwrite')
        return input_cad_invoice

    def content_address_transformer(self, transformer_uri=None):
        if transformer_uri is not None:
            self.transformer_uri = transformer_uri
        bom: RDD = self.spark.sparkContext \
            .parallelize([self.transformer_uri]) \
            .repartition(1) \
            .map(content_address_tranformer) \
            .collect()[0]
        return bom

    # def get_transform(self, transform_cid: isa(str)):

    def read(self, bucket, input_path, cai_uri=None):
        # ToDO: include Transformer
        # ToDO: return cadContext
        if cai_uri is not None:
            self.cai_uri = cai_uri
        return self.content_address_dataset(bucket, input_path, self.cai_uri)

    @overload
    def transform(self, transform_func: isa(FunctionType)):
        self.transform_func = transform_func
        self.catContext = self.cad.transform(transform_func)

        s3_out_put_keys = get_s3_keys(self.cao_bucket, self.cao_data_dir)
        partition_count = len(s3_out_put_keys)
        self.catContext['cao_invoice']: RDD = self.spark.sparkContext \
            .parallelize(s3_out_put_keys) \
            .repartition(partition_count) \
            .map(cad_invoicing)
        self.cai_data_uri = self.catContext['cai_data_uri']
        self.cao_data_uri = self.catContext['cao_data_uri']
        self.caiInvoice: RDD = self.catContext['cai_invoice']
        self.caoInvoice: RDD = self.catContext['cao_invoice']
        self.cad.invoice: RDD = self.caoInvoice
        self.cai: DataFrame = self.catContext['cai']
        self.cao: DataFrame = self.catContext['cao']

        return self.catContext

    # cai_invoice_uri: str, cao_data_uri: str, transform_func
    def execute(self, transform_func=None):
        self.transform_func = transform_func
        self.catContext = self.cad.execute(
            cai_invoice_uri=self.cai_invoice_uri,
            cao_data_uri=self.cao_data_uri,
            transform_func=transform_func
        )
        s3_out_put_keys = get_s3_keys(self.cao_bucket, self.cao_data_dir)
        partition_count = len(s3_out_put_keys)
        self.catContext['cao_invoice']: RDD = self.spark.sparkContext \
            .parallelize(s3_out_put_keys) \
            .repartition(partition_count) \
            .map(cad_invoicing)
        self.cai_data_uri = self.catContext['cai_data_uri']
        self.cao_data_uri = self.catContext['cao_data_uri']
        self.cai_invoice_uri = self.catContext['cai_invoice_uri']
        self.caiInvoice: RDD = self.catContext['cai_invoice']
        self.caoInvoice: RDD = self.catContext['cao_invoice']
        self.cad.invoice: RDD = self.caoInvoice
        self.cai: DataFrame = self.catContext['cai']
        self.cao: DataFrame = self.catContext['cao']
        return self.catContext
        # return {
        #     'cai': self.cai,
        #     'cai_invoice': self.caiInvoice,
        #     'cao': self.cao,
        #     'cao_invoice': self.caoInvoice
        # }
