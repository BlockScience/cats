import os, time, boto3, subprocess
from pprint import pprint

from pyspark import RDD
from pyspark.sql import SparkSession, DataFrame

# print(os.getenv('AWS_ACCESS_KEY_ID'))
# print(os.environ.get('AWS_SECRET_ACCESS_KEY'))
# exit()

spark = SparkSession \
        .builder \
        .appName("ipfsIngest") \
        .getOrCreate()
spark.sparkContext.setLogLevel("OFF")
sc = spark.sparkContext
# WORK_DIR = '/opt/spark/work-dir'
# IPFS_DIR = f'{WORK_DIR}/ipfs'
# INPUT = f"{WORK_DIR}/job/input/df"
# bc_WORK_DIR = sc.broadcast(WORK_DIR)
# bc_IPFS_DIR = sc.broadcast(IPFS_DIR)
# bc_INPUT = sc.broadcast(INPUT)

s3 = boto3.client(
    's3',
    region_name='us-east-2',
    aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
    aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY')
)


def get_s3_keys(bucket):
    """Get a list of keys in an S3 bucket."""
    keys = []
    resp = s3.list_objects_v2(Bucket=bucket, Prefix='input/df/')
    for obj in resp['Contents']:
        keys.append(obj['Key'])
    keys.remove('input/df/')
    return keys


def get_ipfs_id(file_path_key):
    import json
    WORK_DIR = '/opt/spark/work-dir'
    IPFS_DIR = f'{WORK_DIR}/ipfs'
    ipfs_id = open(f'{IPFS_DIR}/ipfs_id.json')
    cad_part_id_dict = json.load(ipfs_id)
    cad_part_id_dict["FilePathKey"] = file_path_key

    return cad_part_id_dict


def cad_part_invoice(cad_part_id_dict):
    import boto3
    s3 = boto3.client(
        's3',
        region_name='us-east-2',
        aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY')
    )

    WORK_DIR = '/opt/spark/work-dir'
    INPUT = f"{WORK_DIR}/job/input/df"
    file_path_key = cad_part_id_dict["FilePathKey"]
    NODE_FILE_PATH = f"{WORK_DIR}/job/{file_path_key}"
    ipfs_addresses = cad_part_id_dict["Addresses"]
    ip4_tcp_addresses = [x for x in ipfs_addresses if ('tcp' in x) and ('ip4' in x) and ('127.0.0.1' not in x)]
    file_name = file_path_key.split('/')[-1]

    subprocess.check_call(f"mkdir -p {INPUT}".split(' '))
    s3.download_file(Bucket='cats-public', Key=file_path_key, Filename=NODE_FILE_PATH) # delete after transfer
    ipfs_add = f'ipfs add {INPUT}/{file_name}'.split(' ')
    [ipfs_action, cid, _file_name] = subprocess.check_output(ipfs_add).decode('ascii').replace('\n', '').split(' ')

    return {
        'cid': cid,
        'addresses': ip4_tcp_addresses,
        'filename': file_name,
        'action': ipfs_action,
        'file_key': file_path_key
    }


def ipfs_caching(file_path_key):
    return cad_part_invoice(get_ipfs_id(file_path_key))


if __name__ == "__main__":
    """
        Usage: IPFS Ingest
    """

    # Sub Transformation using IPFS Compute
    s3_input_keys = get_s3_keys('cats-public')

    executor_count = 2
    partition_count = len(s3_input_keys)
    if __name__ == '__main__':
        input_cad_invoice: RDD = sc \
            .parallelize(s3_input_keys) \
            .repartition(partition_count) \
            .map(ipfs_caching)


    input_cad_invoice_df = input_cad_invoice.toDF()
    input_cad_invoice_df.write.json('s3a://cats-public/cad-store/cad/cai/invoices', mode='overwrite')
    pprint(input_cad_invoice.collect())
    # input_cad_invoice_df.show(truncate=False)

    # pprint(sc.parallelize(s3_input_keys).collect())
    while True:
        time.sleep(1)

    spark.stop()
